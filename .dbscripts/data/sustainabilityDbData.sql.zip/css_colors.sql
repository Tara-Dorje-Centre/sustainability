-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2013 at 08:19 AM
-- Server version: 5.1.68-cll
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: 'taradorj_projectsdev'
--

--
-- Dumping data for table 'css_colors'
--

INSERT INTO css_colors (`name`) VALUES('AliceBlue');
INSERT INTO css_colors (`name`) VALUES('AntiqueWhite');
INSERT INTO css_colors (`name`) VALUES('Aqua');
INSERT INTO css_colors (`name`) VALUES('Aquamarine');
INSERT INTO css_colors (`name`) VALUES('Azure');
INSERT INTO css_colors (`name`) VALUES('Beige');
INSERT INTO css_colors (`name`) VALUES('Bisque');
INSERT INTO css_colors (`name`) VALUES('Black');
INSERT INTO css_colors (`name`) VALUES('BlanchedAlmond');
INSERT INTO css_colors (`name`) VALUES('Blue');
INSERT INTO css_colors (`name`) VALUES('BlueViolet');
INSERT INTO css_colors (`name`) VALUES('Brown');
INSERT INTO css_colors (`name`) VALUES('Burlywood');
INSERT INTO css_colors (`name`) VALUES('CadetBlue');
INSERT INTO css_colors (`name`) VALUES('Chartreuse');
INSERT INTO css_colors (`name`) VALUES('Chocolate');
INSERT INTO css_colors (`name`) VALUES('Coral');
INSERT INTO css_colors (`name`) VALUES('CornflowerBlue');
INSERT INTO css_colors (`name`) VALUES('Cornsilk');
INSERT INTO css_colors (`name`) VALUES('Crimson');
INSERT INTO css_colors (`name`) VALUES('Cyan');
INSERT INTO css_colors (`name`) VALUES('DarkBlue');
INSERT INTO css_colors (`name`) VALUES('DarkCyan');
INSERT INTO css_colors (`name`) VALUES('DarkGoldenRod');
INSERT INTO css_colors (`name`) VALUES('DarkGray');
INSERT INTO css_colors (`name`) VALUES('DarkGrey');
INSERT INTO css_colors (`name`) VALUES('DarkGreen');
INSERT INTO css_colors (`name`) VALUES('DarkKhaki');
INSERT INTO css_colors (`name`) VALUES('DarkMagenta');
INSERT INTO css_colors (`name`) VALUES('DarkOliveGreen');
INSERT INTO css_colors (`name`) VALUES('DarkOrange');
INSERT INTO css_colors (`name`) VALUES('DarkOrchid');
INSERT INTO css_colors (`name`) VALUES('DarkRed');
INSERT INTO css_colors (`name`) VALUES('DarkSalmon');
INSERT INTO css_colors (`name`) VALUES('DarkSeaGreen');
INSERT INTO css_colors (`name`) VALUES('DarkSlateBlue');
INSERT INTO css_colors (`name`) VALUES('DarkSlateGray');
INSERT INTO css_colors (`name`) VALUES('DarkSlateGrey');
INSERT INTO css_colors (`name`) VALUES('DarkTurquoise');
INSERT INTO css_colors (`name`) VALUES('DarkViolet');
INSERT INTO css_colors (`name`) VALUES('DeepPink');
INSERT INTO css_colors (`name`) VALUES('DeepSkyBlue');
INSERT INTO css_colors (`name`) VALUES('DimGray');
INSERT INTO css_colors (`name`) VALUES('DimGrey');
INSERT INTO css_colors (`name`) VALUES('DodgerBlue');
INSERT INTO css_colors (`name`) VALUES('FireBrick');
INSERT INTO css_colors (`name`) VALUES('FloralWhite');
INSERT INTO css_colors (`name`) VALUES('ForestGreen');
INSERT INTO css_colors (`name`) VALUES('Fuschia');
INSERT INTO css_colors (`name`) VALUES('Gainsboro');
INSERT INTO css_colors (`name`) VALUES('GhostWhite');
INSERT INTO css_colors (`name`) VALUES('Gold');
INSERT INTO css_colors (`name`) VALUES('GoldenRod');
INSERT INTO css_colors (`name`) VALUES('Gray');
INSERT INTO css_colors (`name`) VALUES('Green');
INSERT INTO css_colors (`name`) VALUES('GreenYellow');
INSERT INTO css_colors (`name`) VALUES('HoneyDew');
INSERT INTO css_colors (`name`) VALUES('HotPink');
INSERT INTO css_colors (`name`) VALUES('IndianRed');
INSERT INTO css_colors (`name`) VALUES('Indigo');
INSERT INTO css_colors (`name`) VALUES('Ivory');
INSERT INTO css_colors (`name`) VALUES('Khaki');
INSERT INTO css_colors (`name`) VALUES('Lavender');
INSERT INTO css_colors (`name`) VALUES('LavenderBlush');
INSERT INTO css_colors (`name`) VALUES('LawnGreen');
INSERT INTO css_colors (`name`) VALUES('LemonChiffon');
INSERT INTO css_colors (`name`) VALUES('LightBlue');
INSERT INTO css_colors (`name`) VALUES('LightCoral');
INSERT INTO css_colors (`name`) VALUES('LightCyan');
INSERT INTO css_colors (`name`) VALUES('LightGoldenRodYellow');
INSERT INTO css_colors (`name`) VALUES('LightGray');
INSERT INTO css_colors (`name`) VALUES('LightGrey');
INSERT INTO css_colors (`name`) VALUES('LightGreen');
INSERT INTO css_colors (`name`) VALUES('LightPink');
INSERT INTO css_colors (`name`) VALUES('LightSalmon');
INSERT INTO css_colors (`name`) VALUES('LightSeaGreen');
INSERT INTO css_colors (`name`) VALUES('LightSkyBlue');
INSERT INTO css_colors (`name`) VALUES('LightSlateGray');
INSERT INTO css_colors (`name`) VALUES('LightSteelBlue');
INSERT INTO css_colors (`name`) VALUES('LightYellow');
INSERT INTO css_colors (`name`) VALUES('Lime');
INSERT INTO css_colors (`name`) VALUES('LimeGreen');
INSERT INTO css_colors (`name`) VALUES('Linen');
INSERT INTO css_colors (`name`) VALUES('Magenta');
INSERT INTO css_colors (`name`) VALUES('Maroon');
INSERT INTO css_colors (`name`) VALUES('MediumAquaMarine');
INSERT INTO css_colors (`name`) VALUES('MediumBlue');
INSERT INTO css_colors (`name`) VALUES('MediumOrchid');
INSERT INTO css_colors (`name`) VALUES('MediumPurple');
INSERT INTO css_colors (`name`) VALUES('MediumSeaGreen');
INSERT INTO css_colors (`name`) VALUES('MediumSlateBlue');
INSERT INTO css_colors (`name`) VALUES('MediumSpringGreen');
INSERT INTO css_colors (`name`) VALUES('MediumTurquoise');
INSERT INTO css_colors (`name`) VALUES('MediumVioletRed');
INSERT INTO css_colors (`name`) VALUES('MidnightBlue');
INSERT INTO css_colors (`name`) VALUES('MintCream');
INSERT INTO css_colors (`name`) VALUES('MistyRose');
INSERT INTO css_colors (`name`) VALUES('Moccasin');
INSERT INTO css_colors (`name`) VALUES('NavajoWhite');
INSERT INTO css_colors (`name`) VALUES('Navy');
INSERT INTO css_colors (`name`) VALUES('OldLace');
INSERT INTO css_colors (`name`) VALUES('Olive');
INSERT INTO css_colors (`name`) VALUES('OliveDrab');
INSERT INTO css_colors (`name`) VALUES('Orange');
INSERT INTO css_colors (`name`) VALUES('OrangeRed');
INSERT INTO css_colors (`name`) VALUES('Orchid');
INSERT INTO css_colors (`name`) VALUES('PaleGoldenRod');
INSERT INTO css_colors (`name`) VALUES('PaleGreen');
INSERT INTO css_colors (`name`) VALUES('PaleTurquoise');
INSERT INTO css_colors (`name`) VALUES('PaleVioletRed');
INSERT INTO css_colors (`name`) VALUES('PapayaWhip');
INSERT INTO css_colors (`name`) VALUES('PeachPuff');
INSERT INTO css_colors (`name`) VALUES('Peru');
INSERT INTO css_colors (`name`) VALUES('Pink');
INSERT INTO css_colors (`name`) VALUES('Plum');
INSERT INTO css_colors (`name`) VALUES('PowderBlue');
INSERT INTO css_colors (`name`) VALUES('Purple');
INSERT INTO css_colors (`name`) VALUES('Red');
INSERT INTO css_colors (`name`) VALUES('RosyBrown');
INSERT INTO css_colors (`name`) VALUES('RoyalBlue');
INSERT INTO css_colors (`name`) VALUES('SaddleBrown');
INSERT INTO css_colors (`name`) VALUES('Salmon');
INSERT INTO css_colors (`name`) VALUES('SandyBrown');
INSERT INTO css_colors (`name`) VALUES('SeaGreen');
INSERT INTO css_colors (`name`) VALUES('SeaShell');
INSERT INTO css_colors (`name`) VALUES('Sienna');
INSERT INTO css_colors (`name`) VALUES('Silver');
INSERT INTO css_colors (`name`) VALUES('SkyBlue');
INSERT INTO css_colors (`name`) VALUES('SlateBlue');
INSERT INTO css_colors (`name`) VALUES('SlateGray');
INSERT INTO css_colors (`name`) VALUES('Snow');
INSERT INTO css_colors (`name`) VALUES('SpringGreen');
INSERT INTO css_colors (`name`) VALUES('SteelBlue');
INSERT INTO css_colors (`name`) VALUES('Tan');
INSERT INTO css_colors (`name`) VALUES('Teal');
INSERT INTO css_colors (`name`) VALUES('Thistle');
INSERT INTO css_colors (`name`) VALUES('Tomato');
INSERT INTO css_colors (`name`) VALUES('Turquoise');
INSERT INTO css_colors (`name`) VALUES('Violet');
INSERT INTO css_colors (`name`) VALUES('Wheat');
INSERT INTO css_colors (`name`) VALUES('White');
INSERT INTO css_colors (`name`) VALUES('WhiteSmoke');
INSERT INTO css_colors (`name`) VALUES('Yellow');
INSERT INTO css_colors (`name`) VALUES('YellowGreen');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
