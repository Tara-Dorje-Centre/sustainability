SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


INSERT INTO css_fonts (`name`) VALUES('Lucida Console, Monaco, monospace');
INSERT INTO css_fonts (`name`) VALUES('Courier New, Courier, monospace');
INSERT INTO css_fonts (`name`) VALUES('Verdana, Geneva, sans-serif');
INSERT INTO css_fonts (`name`) VALUES('Trebuchet MS, Helvetica, sans-serif');
INSERT INTO css_fonts (`name`) VALUES('Tahoma, Geneva, sans-serif');
INSERT INTO css_fonts (`name`) VALUES('Lucida Sans Unicode, Lucida Grande, sans-serif');
INSERT INTO css_fonts (`name`) VALUES('Impact, Charcoal, sans-serif');
INSERT INTO css_fonts (`name`) VALUES('Comic Sans MS, cursive, sans-serif');
INSERT INTO css_fonts (`name`) VALUES('Arial Black, Gadget, sans-serif');
INSERT INTO css_fonts (`name`) VALUES('Arial, Helvetica, sans-serif');
INSERT INTO css_fonts (`name`) VALUES('Times New Roman, Times, serif');
INSERT INTO css_fonts (`name`) VALUES('Palatino Linotype, Book Antiqua, Palatino, serif');
INSERT INTO css_fonts (`name`) VALUES('Georgia, serif');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
